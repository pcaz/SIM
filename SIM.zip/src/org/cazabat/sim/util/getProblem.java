package org.cazabat.sim.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.cazabat.sim.model.Edge;
import org.cazabat.sim.model.Graph;
import org.cazabat.sim.model.Vertex;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public final class getProblem {
	private getProblem(){
		}
	public static Problem get(String file) {
		
		List<Vertex> nodes = new ArrayList<Vertex>();
		List<Edge> edges = new ArrayList<Edge>();
		boolean Or=false;
		Vertex source=null;
		Vertex destination=null;
		
		Document document = null;
		DocumentBuilderFactory factory = null;
		
		  
	    try{
	    	factory = DocumentBuilderFactory.newInstance();
	    	DocumentBuilder builder = factory.newDocumentBuilder();
	    	document = builder.parse(file);		
	    	
	    }catch(Exception e){
	    	e.printStackTrace();
	    }
	    
	    Element racine = document.getDocumentElement();
	    NodeList racineNoeuds = racine.getChildNodes();
	    
	    // First, we get the nodes
	    
	    NodeList xml = racine.getElementsByTagName("Nodes");
	    Element xmlNodes=null;
	    
	    for(int i=0; i< racineNoeuds.getLength();i++){
	    	if(racineNoeuds.item(i).getNodeName().equals ( "NODES")){
	    		xmlNodes = (Element) racineNoeuds.item(i);
	    		break;
	    	}
	    }
	    NodeList xmlNode = xmlNodes.getElementsByTagName("NODE");
	    for(int i=0;i<xmlNode.getLength();i++)
	    {
	    	nodes.add(new Vertex(xmlNode.item(i).getTextContent().trim()));
	    }
        // then, the edges.
	    
	   
	    Element xmlEdges=null;
	    for (int i=0;i<racineNoeuds.getLength();i++) {
	    	if(racineNoeuds.item(i).getNodeName().equals ( "EDGES")){
	    		xmlEdges = (Element) racineNoeuds.item(i);
	    		break;
	    	}
	    }
	     
	    NodeList xmlEdge = xmlEdges.getElementsByTagName("EDGE");
	    
	    Element xmlEntry;
	    int vv=xmlEdge.getLength();
	    for (int i=0;i<xmlEdge.getLength();i++) {
	    		 xmlEntry = (Element) xmlEdge.item(i);
	    		 NodeList xmlSource = xmlEntry.getElementsByTagName("SOURCE");
	    		 String xSource = xmlSource.item(0).getTextContent().trim();
	    		 NodeList xmlDestination = xmlEntry.getElementsByTagName("DESTINATION");
	    		 String xDestination = xmlDestination.item(0).getTextContent().trim();
	    		 NodeList xmlWeight = xmlEntry.getElementsByTagName("WEIGHT");
	    		 String xWeight = xmlWeight.item(0).getTextContent().trim();
	    		 Vertex xxSource=null;
    			 Vertex xxDestination=null;
	    		 for(Iterator<Vertex> it=nodes.iterator();it.hasNext();)
	    		 {
	    			 
	    			 Vertex val=it.next(); 
	    			 if(val.getName().equals(xSource)) {xxSource=val;}		 
	    		     if(val.getName().equals(xDestination)) {xxDestination=val;}
                     if(xxSource != null && xxDestination != null) {break;}
                   }
	    		 float xxWeight = Float.parseFloat(xWeight);
	    		 edges.add(new Edge(xxSource,xxDestination,xxWeight));
	    }
	    
	    
	    // at last for the graph, get the orientation
	    Element xmlSource=null;
	    Element xmlDestination=null;
	    NodeList nl=null;
	     
	    NodeList xmlOrientation = racine.getElementsByTagName("ISORIENTED");
	    String xOrientation=xmlOrientation.item(0).getTextContent().trim();
	     if(xOrientation.equals("1")) {Or=true;} else {Or=false;}
	    
	     
	    // so,now for the source and destination of the research
	     for(int i=0; i< racineNoeuds.getLength();i++){
		    	if(racineNoeuds.item(i).getNodeName().equals ( "SOURCE")){
		    		xmlSource = (Element) racineNoeuds.item(i);
		    		break;
		    	}
		    }
 
		    String xmlAlgoSource=xmlSource.getTextContent().trim();
		    for(Iterator<Vertex> it=nodes.iterator();it.hasNext();)
   		 {
   			 Vertex val=it.next(); 
   			 if(val.getName().equals(xmlAlgoSource)) {
   				 source=val;		 
                break;
   			 }
           }
	     
		    for(int i=0; i< racineNoeuds.getLength();i++){
		    	if(racineNoeuds.item(i).getNodeName().equals ( "DESTINATION")){
		    		xmlDestination = (Element) racineNoeuds.item(i);
		    		break;
		    	}
		    }
 
		    String xmlAlgoDestination=xmlDestination.getTextContent().trim();
		    for(Iterator<Vertex> it=nodes.iterator();it.hasNext();)
   		 {
   			 Vertex val=it.next(); 
   			 if(val.getName().equals(xmlAlgoDestination)) {
   				 destination=val;		 
                break;
   			 }
           }

		    return new Problem (new Graph(nodes,edges,Or), source, destination);
	}

}
