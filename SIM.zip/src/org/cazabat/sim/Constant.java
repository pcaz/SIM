/**
 * 
 */
package org.cazabat.sim;

/**
 * @author pascaz10
 *
 */
public class Constant {

	public static final boolean SUCCESS=true;
	public static final boolean ERROR=false;
	
	public static final float UNDEFINED=999;
	public static enum SYSTEM {LAMBERT93,WSG84};
	
 
}
